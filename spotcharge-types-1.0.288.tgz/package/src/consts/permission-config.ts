export const permissionConfig = {
    'VIEW_FLEET_DASHBOARD': {
        key: 'VIEW_FLEET_DASHBOARD',
        formattedPermission: 'Can View Fleet Dashboard',
    },
    'VIEW_PUBLIC_DASHBOARD': {
        key: 'VIEW_PUBLIC_DASHBOARD',
        formattedPermission: 'Can View Public Dashboard',
    },
    'LIST_FRANCHISES': {
        key: 'LIST_FRANCHISES',
        formattedPermission: 'Can View Franchise List',
    },
    'ADD_FRANCHISE': {
        key: 'ADD_FRANCHISE',
        formattedPermission: 'Can Add Franchise',
    },
    'EDIT_FRANCHISE': {
        key: 'EDIT_FRANCHISE',
        formattedPermission: 'Can Edit Franchise',
    },
    'VIEW_FRANCHISE': {
        key: 'VIEW_FRANCHISE',
        formattedPermission: 'Can View Franchise',
    },
    'DELETE_FRANCHISE': {
        key: 'DELETE_FRANCHISE',
        formattedPermission: 'Can Delete Franchise',
    },
    'LIST_FRANCHISE_USERS': {
        key: 'LIST_FRANCHISE_USERS',
        formattedPermission: 'Can View Franchise Users List',
    },
    'ADD_FRANCHISE_USER': {
        key: 'ADD_FRANCHISE_USER',
        formattedPermission: 'Can Add Franchise User',
    },
    'VIEW_FRANCHISE_USER': {
        key: 'VIEW_FRANCHISE_USER',
        formattedPermission: 'Can View Franchise User',
    },
    'EDIT_FRANCHISE_USER': {
        key: 'EDIT_FRANCHISE_USER',
        formattedPermission: 'Can Edit Franchise User',
    },
    'EDIT_FRANCHISE_SETTING': {
        key: 'EDIT_FRANCHISE_SETTING',
        formattedPermission: 'Can Edit Franchise Setting',
    },
    'EDIT_FRANCHISE_ACCOUNT_SETTING': {
        key: 'EDIT_FRANCHISE_ACCOUNT_SETTING',
        formattedPermission: 'Can Edit Franchise Account Setting',
    },
    'EDIT_FRANCHISE_PROFILE': {
        key: 'EDIT_FRANCHISE_PROFILE',
        formattedPermission: 'Can Edit Franchise Profile',
    },
    'LIST_FLEETS': {
        key: 'LIST_FLEETS',
        formattedPermission: 'Can View Fleet List',
    },
    'ADD_FLEET': {
        key: 'ADD_FLEET',
        formattedPermission: 'Can Add Fleet',
    },
    'EDIT_FLEET': {
        key: 'EDIT_FLEET',
        formattedPermission: 'Can Edit Fleet',
    },
    'DELETE_FLEET': {
        key: 'DELETE_FLEET',
        formattedPermission: 'Can Delete Fleet',
    },
    'LIST_FLEET_USERS': {
        key: 'LIST_FLEET_USERS',
        formattedPermission: 'Can View Fleet User List',
    },
    'ADD_FLEET_USER': {
        key: 'ADD_FLEET_USER',
        formattedPermission: 'Can Add Fleet User',
    },
    'EDIT_FLEET_USER': {
        key: 'EDIT_FLEET_USER',
        formattedPermission: 'Can Edit Fleet User',
    },
    'DELETE_FLEET_USER': {
        key: 'DELETE_FLEET_USER',
        formattedPermission: 'Can Delete Fleet User',
    },
    'LIST_FLEET_OPERATORS': {
        key: 'LIST_FLEET_OPERATORS',
        formattedPermission: 'Can View Fleet Operator List',
    },
    'ADD_FLEET_OPERATOR': {
        key: 'ADD_FLEET_OPERATOR',
        formattedPermission: 'Can Add Fleet Operator',
    },
    'EDIT_FLEET_OPERATOR': {
        key: 'EDIT_FLEET_OPERATOR',
        formattedPermission: 'Can Edit Fleet Operator',
    },
    'DELETE_FLEET_OPERATOR': {
        key: 'DELETE_FLEET_OPERATOR',
        formattedPermission: 'Can Delete Fleet Operator',
    },
    'LIST_FLEET_VEHICLES': {
        key: 'LIST_FLEET_VEHICLES',
        formattedPermission: 'Can View Fleet Vehicle List',
    },
    'ADD_FLEET_VEHICLE': {
        key: 'ADD_FLEET_VEHICLE',
        formattedPermission: 'Can Add Fleet Vehicle',
    },
    'EDIT_FLEET_VEHICLE': {
        key: 'EDIT_FLEET_VEHICLE',
        formattedPermission: 'Can Edit Fleet Vehicle',
    },
    'DELETE_FLEET_VEHICLE': {
        key: 'DELETE_FLEET_VEHICLE',
        formattedPermission: 'Can Delete Fleet Vehicle',
    },
    'LIST_CHARGER_ERRORS': {
        key: 'LIST_CHARGER_ERRORS',
        formattedPermission: 'Can View Charger Error List',
    },
    'VIEW_CHARGER_ERROR': {
        key: 'VIEW_CHARGER_ERROR',
        formattedPermission: 'Can View Charger Error',
    },
    'DOWNLOAD_CHARGER_ERROR_LOG': {
        key: 'DOWNLOAD_CHARGER_ERROR',
        formattedPermission: 'Can Download Charger Error Log',
    },
    'LIST_FLEET_ORDER_SCHEDULES': {
        key: 'LIST_FLEET_ORDER_SCHEDULES',
        formattedPermission: 'Can View Fleet Order Schedule List',
    },
    'VIEW_FLEET_ORDER_SCHEDULE': {
        key: 'VIEW_FLEET_ORDER_SCHEDULE',
        formattedPermission: 'Can View Fleet Order Schedule',
    },
    'STOP_FLEET_ORDER_SCHEDULE': {
        key: 'STOP_FLEET_ORDER_SCHEDULE',
        formattedPermission: 'Can Stop Fleet Order Schedule',
    },
    'RESTART_FLEET_ORDER_SCHEDULE': {
        key: 'RESTART_FLEET_ORDER_SCHEDULE',
        formattedPermission: 'Can Restart Fleet Order Schedule',
    },
    'LIST_PUBLIC_BOOKINGS': {
        key: 'LIST_PUBLIC_BOOKINGS',
        formattedPermission: 'Can View Public Booking List',
    },
    'VIEW_PUBLIC_BOOKING': {
        key: 'VIEW_PUBLIC_BOOKING',
        formattedPermission: 'Can View Public Booking',
    },
    'START_PUBLIC_BOOKING': {
        key: 'START_PUBLIC_BOOKING',
        formattedPermission: 'Can Start Public Booking',
    },
    'CANCEL_PUBLIC_BOOKING': {
        key: 'CANCEL_PUBLIC_BOOKING',
        formattedPermission: 'Can Cancel Public Booking',
    },
    'ISSUE_BOOKING_REFUND': {
        key: 'ISSUE_BOOKING_REFUND',
        formattedPermission: 'Can Issue Booking Refund',
    },
    'LIST_PUBLIC_INVOICES': {
        key: 'LIST_PUBLIC_INVOICES',
        formattedPermission: 'Can View Public Invoice List',
    },
    'VIEW_PUBLIC_INVOICE': {
        key: 'VIEW_PUBLIC_INVOICE',
        formattedPermission: 'Can View Public Invoice',
    },
    'DOWNLOAD_PUBLIC_INVOICE_LOG': {
        key: 'DOWNLOAD_PUBLIC_INVOICE_LOG',
        formattedPermission: 'Can Download Public Invoice Log',
    },
    'DOWNLOAD_PUBLIC_INVOICE_PDF': {
        key: 'DOWNLOAD_PUBLIC_INVOICE_PDF',
        formattedPermission: 'Can Download Public Invoice PDF',
    },
    'DOWNLOAD_PUBLIC_INVOICE': {
        key: 'DOWNLOAD_PUBLIC_INVOICE',
        formattedPermission: 'Can Download Public Invoice',
    },
    'LIST_PUBLIC_INVOICE_DOWNLOAD_REQUESTS': {
        key: 'LIST_PUBLIC_INVOICE_DOWNLOAD_REQUESTS',
        formattedPermission: 'Can View Public Invoice Download Request List',
    },
    'LIST_PUBLIC_USERS': {
        key: 'LIST_PUBLIC_USERS',
        formattedPermission: 'Can View Public User List',
    },
    'VIEW_PUBLIC_USER': {
        key: 'VIEW_PUBLIC_USER',
        formattedPermission: 'Can View Public User',
    },
    'EDIT_PUBLIC_USER': {
        key: 'EDIT_PUBLIC_USER',
        formattedPermission: 'Can Edit Public User',
    },
    'EDIT_PUBLIC_USER_BLOCK_STATUS': {
        key: 'EDIT_PUBLIC_USER_BLOCK_STATUS',
        formattedPermission: 'Can Edit Public User Block Status',
    },
    'VIEW_PUBLIC_USER_SUMMARY': {
        key: 'VIEW_PUBLIC_USER_SUMMARY',
        formattedPermission: 'Can View Public User Summary',
    },
    'VIEW_PUBLIC_USER_DETAIL': {
        key: 'VIEW_PUBLIC_USER_DETAIL',
        formattedPermission: 'Can View Public User Detail',
    },
    'VIEW_PUBLIC_USER_BOOKING': {
        key: 'VIEW_PUBLIC_USER_BOOKING',
        formattedPermission: 'Can View Public User Booking',
    },
    'VIEW_PUBLIC_USER_INVOICE': {
        key: 'VIEW_PUBLIC_USER_INVOICE',
        formattedPermission: 'Can View Public User Invoice',
    },
    'EXPORT_PUBLIC_USER_INVOICE': {
        key: 'EXPORT_PUBLIC_USER_INVOICE',
        formattedPermission: 'Can Export Public User Invoice',
    },
    'VIEW_PUBLIC_USER_WALLET': {
        key: 'VIEW_PUBLIC_USER_WALLET',
        formattedPermission: 'Can View Public User Wallet',
    },
    'UPDATE_PUBLIC_USER_WALLET_BALANCE': {
        key: 'UPDATE_PUBLIC_USER_WALLET_BALANCE',
        formattedPermission: 'Can Update Public User Wallet Balance',
    },
    'LIST_PUBLIC_SCHEDULES': {
        key: 'LIST_PUBLIC_SCHEDULES',
        formattedPermission: 'Can View Public Schedule List',
    },
    'VIEW_PUBLIC_SCHEDULE': {
        key: 'VIEW_PUBLIC_SCHEDULE',
        formattedPermission: 'Can View Public Schedule',
    },
    'RESUME_PUBLIC_SCHEDULE': {
        key: 'RESUME_PUBLIC_SCHEDULE',
        formattedPermission: 'Can Resume Public Schedule',
    },
    'STOP_PUBLIC_SCHEDULE': {
        key: 'STOP_PUBLIC_SCHEDULE',
        formattedPermission: 'Can Stop Public Schedule',
    },
    'LIST_CHARGERS': {
        key: 'LIST_CHARGERS',
        formattedPermission: 'Can View Charger List',
    },
    'DISPLAY_CHARGERS_ON_MAP': {
        key: 'DISPLAY_CHARGERS_ON_MAP',
        formattedPermission: 'Can View Chargers On Map',
    },
    'ADD_CHARGER': {
        key: 'ADD_CHARGER',
        formattedPermission: 'Can Add Charger',
    },
    'VIEW_CHARGER_DETAIL': {
        key: 'VIEW_CHARGER_DETAIL',
        formattedPermission: 'Can View Charger Detail',
    },
    'EDIT_CHARGER': {
        key: 'EDIT_CHARGER',
        formattedPermission: 'Can Edit Charger',
    },
    'EDIT_CHARGER_CONFIGURATION': {
        key: 'EDIT_CHARGER_CONFIGURATION',
        formattedPermission: 'Can Edit Charger Configuration',
    },
    'EDIT_CHARGER_FIRMWARE': {
        key: 'EDIT_CHARGER_FIRMWARE',
        formattedPermission: 'Can Edit Charger Firmware',
    },
    'VIEW_CHARGER_LOGS': {
        key: 'VIEW_CHARGER_LOGS',
        formattedPermission: 'Can View Charger Logs',
    },
    'VIEW_CHARGER_TARIFF': {
        key: 'VIEW_CHARGER_TARIFF',
        formattedPermission: 'Can View Charger Tariff',
    },
    'VIEW_CHARGER_OCPP_COMMANDS': {
        key: 'VIEW_CHARGER_OCPP_COMMANDS',
        formattedPermission: 'Can View Charger Ocpp Commands',
    },
    'DELETE_CHARGER': {
        key: 'DELETE_CHARGER',
        formattedPermission: 'Can Delete Charger',
    },
    'LIST_CHARGER_CAPACITIES': {
        key: 'LIST_CHARGER_CAPACITIES',
        formattedPermission: 'Can View Charger Capacity List',
    },
    'ADD_CHARGER_CAPACITY': {
        key: 'ADD_CHARGER_CAPACITY',
        formattedPermission: 'Can Add Charger Capacity',
    },
    'EDIT_CHARGER_CAPACITY': {
        key: 'EDIT_CHARGER_CAPACITY',
        formattedPermission: 'Can Edit Charger Capacity',
    },
    'DELETE_CHARGER_CAPACITY': {
        key: 'DELETE_CHARGER_CAPACITY',
        formattedPermission: 'Can Delete Charger Capacity',
    },
    'VIEW_FLEET_ORDERS_REPORT': {
        key: 'VIEW_FLEET_ORDERS_REPORT',
        formattedPermission: 'Can View Fleet Orders Report',
    },
    'VIEW_FLEET_ORDER_REPORT_DETAIL': {
        key: 'VIEW_FLEET_ORDER_REPORT_DETAIL',
        formattedPermission: 'Can View Fleet Order Report Detail',
    },
    'DOWNLOAD_FLEET_ORDER_LOG': {
        key: 'DOWNLOAD_FLEET_ORDER_LOG',
        formattedPermission: 'Can Download Fleet Order Log',
    },
    'EXPORT_FLEET_ORDERS_REPORT': {
        key: 'EXPORT_FLEET_ORDERS_REPORT',
        formattedPermission: 'Can Export Fleet Orders Report',
    },
    'VIEW_ORDERS_BY_FLEET_VEHICLE_REPORT': {
        key: 'VIEW_ORDERS_BY_FLEET_VEHICLE_REPORT',
        formattedPermission: 'Can View Orders By Fleet Vehicle Report',
    },
    'EXPORT_ORDERS_BY_FLEET_VEHICLE_REPORT': {
        key: 'EXPORT_ORDERS_BY_FLEET_VEHICLE_REPORT',
        formattedPermission: 'Can Export Orders By Fleet Vehicle Report',
    },
    'VIEW_ORDERS_BY_USER_REPORT': {
        key: 'VIEW_ORDERS_BY_USER_REPORT',
        formattedPermission: 'Can View Orders By User Report',
    },
    'EXPORT_ORDERS_BY_USER_REPORT': {
        key: 'EXPORT_ORDERS_BY_USER_REPORT',
        formattedPermission: 'Can Export Orders By User Report',
    },
    'VIEW_ORDERS_BY_FLEET_CHARGER_REPORT': {
        key: 'VIEW_ORDERS_BY_FLEET_CHARGER_REPORT',
        formattedPermission: 'Can View Orders By Fleet Charger Report',
    },
    'EXPORT_ORDERS_BY_FLEET_CHARGER_REPORT': {
        key: 'EXPORT_ORDERS_BY_FLEET_CHARGER_REPORT',
        formattedPermission: 'Can Export Orders By Fleet Charger Report',
    },
    'VIEW_PUBLIC_ORDERS_REPORT': {
        key: 'VIEW_PUBLIC_ORDERS_REPORT',
        formattedPermission: 'Can View Public Orders Report',
    },
    'EXPORT_PUBLIC_ORDERS_REPORT': {
        key: 'EXPORT_PUBLIC_ORDERS_REPORT',
        formattedPermission: 'Can Export Public Orders Report',
    },
    'VIEW_ORDERS_BY_PUBLIC_USER_REPORT': {
        key: 'VIEW_ORDERS_BY_PUBLIC_USER_REPORT',
        formattedPermission: 'Can View Order By Public User Report',
    },
    'EXPORT_ORDERS_BY_PUBLIC_USER_REPORT': {
        key: 'EXPORT_ORDERS_BY_PUBLIC_USER_REPORT',
        formattedPermission: 'Can Export Orders By Public User Report',
    },
    'VIEW_ORDERS_BY_PUBLIC_USER_VEHICLE_REPORT': {
        key: 'VIEW_ORDERS_BY_PUBLIC_USER_VEHICLE_REPORT',
        formattedPermission: 'Can View Orders By Public User Vehicle Report',
    },
    'EXPORT_ORDERS_BY_PUBLIC_USER_VEHICLE_REPORT': {
        key: 'EXPORT_ORDERS_BY_PUBLIC_USER_VEHICLE_REPORT',
        formattedPermission: 'Can Export Orders By Public User Vehicle Report',
    },
    'VIEW_ORDERS_BY_PUBLIC_CHARGER_REPORT': {
        key: 'VIEW_ORDERS_BY_PUBLIC_CHARGER_REPORT',
        formattedPermission: 'Can View Orders By Public Charger Report',
    },
    'EXPORT_ORDERS_BY_PUBLIC_CHARGER_REPORT': {
        key: 'EXPORT_ORDERS_BY_PUBLIC_CHARGER_REPORT',
        formattedPermission: 'Can Export Orders By Public Charger Report',
    },
    'VIEW_FLEET_VEHICLE_REPORT': {
        key: 'VIEW_FLEET_VEHICLE_REPORT',
        formattedPermission: 'Can View Fleet Vehicle Report',
    },
    'EXPORT_FLEET_VEHICLE_REPORT': {
        key: 'EXPORT_FLEET_VEHICLE_REPORT',
        formattedPermission: 'Can Export Fleet Vehicle Report',
    },
    'VIEW_FLEET_VEHICLE_IN_OUT_REPORT': {
        key: 'VIEW_FLEET_VEHICLE_IN_OUT_REPORT',
        formattedPermission: 'Can View Fleet Vehicle In Out Report',
    },
    'VIEW_FLEET_VEHICLE_IN_OUT_REPORT_DETAIL': {
        key: 'VIEW_FLEET_VEHICLE_IN_OUT_REPORT_DETAIL',
        formattedPermission: 'Can View Fleet Vehicle In Out Report Detail',
    },
    'EXPORT_FLEET_VEHICLE_IN_OUT_REPORT': {
        key: 'EXPORT_FLEET_VEHICLE_IN_OUT_REPORT',
        formattedPermission: 'Can Export Fleet Vehicle In Out Report',
    },
    'VIEW_ASSET_IN_OUT_REPORT': {
        key: 'VIEW_ASSET_IN_OUT_REPORT',
        formattedPermission: 'Can View Asset In Out Report',
    },
    'VIEW_ASSET_IN_OUT_REPORT_DETAIL': {
        key: 'VIEW_ASSET_IN_OUT_REPORT_DETAIL',
        formattedPermission: 'Can View Asset In Out Report Detail',
    },
    'EXPORT_ASSET_IN_OUT_REPORT': {
        key: 'EXPORT_ASSET_IN_OUT_REPORT',
        formattedPermission: 'Can Export Asset In Out Report',
    },
    'VIEW_FLEET_VEHICLE_IN_OUT_LOG_REPORT': {
        key: 'VIEW_FLEET_VEHICLE_IN_OUT_LOG_REPORT',
        formattedPermission: 'Can View Fleet Vehicle In Out Log Report',
    },
    'VIEW_FLEET_VEHICLE_IN_OUT_LOG_DETAIL': {
        key: 'VIEW_FLEET_VEHICLE_IN_OUT_LOG_DETAIL',
        formattedPermission: 'Can View Fleet Vehicle In Out Log Detail',
    },
    'EXPORT_FLEET_VEHICLE_IN_OUT_LOG_REPORT': {
        key: 'EXPORT_FLEET_VEHICLE_IN_OUT_LOG_REPORT',
        formattedPermission: 'Can Export Fleet Vehicle In Out Log Report',
    },
    'VIEW_ASSET_IN_OUT_LOG_REPORT': {
        key: 'VIEW_ASSET_IN_OUT_LOG_REPORT',
        formattedPermission: 'Can View Asset In Out Log Report',
    },
    'VIEW_ASSET_IN_OUT_LOG_DETAIL': {
        key: 'VIEW_ASSET_IN_OUT_LOG_DETAIL',
        formattedPermission: 'Can View Asset In Out Log Detail',
    },
    'EXPORT_ASSET_IN_OUT_LOG_REPORT': {
        key: 'EXPORT_ASSET_IN_OUT_LOG_REPORT',
        formattedPermission: 'Can Export Asset In Out Log Report',
    },
    'VIEW_FLEET_VEHICLE_IN_OUT_SUMMARY_REPORT': {
        key: 'VIEW_FLEET_VEHICLE_IN_OUT_SUMMARY_REPORT',
        formattedPermission: 'Can View Fleet Vehicle In Out Summary Report',
    },
    'VIEW_FLEET_VEHICLE_IN_OUT_SUMMARY_REPORT_DETAIL': {
        key: 'VIEW_FLEET_VEHICLE_IN_OUT_SUMMARY_REPORT_DETAIL',
        formattedPermission: 'Can View Fleet Vehicle In Out Summary Report Detail',
    },
    'EXPORT_FLEET_VEHICLE_IN_OUT_SUMMARY_REPORT': {
        key: 'EXPORT_FLEET_VEHICLE_IN_OUT_SUMMARY_REPORT',
        formattedPermission: 'Can Export Fleet Vehicle In Out Summary Report',
    },
    'VIEW_ASSET_IN_OUT_SUMMARY_REPORT': {
        key: 'VIEW_ASSET_IN_OUT_SUMMARY_REPORT',
        formattedPermission: 'Can View Asset In Out Summary Report',
    },
    'EXPORT_ASSET_IN_OUT_SUMMARY_REPORT': {
        key: 'EXPORT_ASSET_IN_OUT_SUMMARY_REPORT',
        formattedPermission: 'Can Export Asset In Out Summary Report',
    },
    'VIEW_ASSET_IN_OUT_SUMMARY_REPORT_DETAIL': {
        key: 'VIEW_ASSET_IN_OUT_SUMMARY_REPORT_DETAIL',
        formattedPermission: 'Can View Asset In Out Summary Report Detail',
    },
    'VIEW_FLEET_VEHICLE_IN_OUT_DIFFERENCE_REPORT': {
        key: 'VIEW_FLEET_VEHICLE_IN_OUT_DIFFERENCE_REPORT',
        formattedPermission: 'Can View Fleet Vehicle In Out Difference Report',
    },
    'EXPORT_FLEET_VEHICLE_IN_OUT_DIFFERENCE_REPORT': {
        key: 'EXPORT_FLEET_VEHICLE_IN_OUT_DIFFERENCE_REPORT',
        formattedPermission: 'Can Export Fleet Vehicle In Out Difference Report',
    },
    'VIEW_CHARGER_REPORT': {
        key: 'VIEW_CHARGER_REPORT',
        formattedPermission: 'Can View Charger Online/Offline Report',
    },
    'EXPORT_CHARGER_REPORT': {
        key: 'EXPORT_CHARGER_REPORT',
        formattedPermission: 'Can Export Charger Online/Offline Report',
    },
    'LIST_CONNECTOR_TYPES': {
        key: 'LIST_CONNECTOR_TYPES',
        formattedPermission: 'Can View Connector Type List',
    },
    'ADD_CONNECTOR_TYPE': {
        key: 'ADD_CONNECTOR_TYPE',
        formattedPermission: 'Can Add Connector Type',
    },
    'EDIT_CONNECTOR_TYPE': {
        key: 'EDIT_CONNECTOR_TYPE',
        formattedPermission: 'Can Edit Connector Type',
    },
    'DELETE_CONNECTOR_TYPE': {
        key: 'DELETE_CONNECTOR_TYPE',
        formattedPermission: 'Can Delete Connector Type',
    },
    'LIST_VENDORS': {
        key: 'LIST_VENDORS',
        formattedPermission: 'Can View Vendor List',
    },
    'ADD_VENDOR': {
        key: 'ADD_VENDOR',
        formattedPermission: 'Can Add Vendor',
    },
    'EDIT_VENDOR': {
        key: 'EDIT_VENDOR',
        formattedPermission: 'Can Edit Vendor',
    },
    'DELETE_VENDOR': {
        key: 'DELETE_VENDOR',
        formattedPermission: 'Can Delete Vendor',
    },
    'LIST_RFIDS': {
        key: 'LIST_RFIDS',
        formattedPermission: 'Can View Rfid List',
    },
    'ADD_RFID': {
        key: 'ADD_RFID',
        formattedPermission: 'Can Add Rfid',
    },
    'EDIT_RFID': {
        key: 'EDIT_RFID',
        formattedPermission: 'Can Edit Rfid',
    },
    'DELETE_RFID': {
        key: 'DELETE_RFID',
        formattedPermission: 'Can Delete Rfid',
    },
    'LIST_VEHICLES': {
        key: 'LIST_VEHICLES',
        formattedPermission: 'Can View Vehicle List',
    },
    'ADD_VEHICLE': {
        key: 'ADD_VEHICLE',
        formattedPermission: 'Can Add Vehicle',
    },
    'EDIT_VEHICLE': {
        key: 'EDIT_VEHICLE',
        formattedPermission: 'Can Edit Vehicle',
    },
    'DELETE_VEHICLE': {
        key: 'DELETE_VEHICLE',
        formattedPermission: 'Can Delete Vehicle',
    },
    'LIST_BRANDS': {
        key: 'LIST_BRANDS',
        formattedPermission: 'Can View Brand List',
    },
    'ADD_BRAND': {
        key: 'ADD_BRAND',
        formattedPermission: 'Can Add Brand',
    },
    'EDIT_BRAND': {
        key: 'EDIT_BRAND',
        formattedPermission: 'Can Edit Brand',
    },
    'DELETE_BRAND': {
        key: 'DELETE_BRAND',
        formattedPermission: 'Can Delete Brand',
    },
    'LIST_LOGS': {
        key: 'LIST_LOGS',
        formattedPermission: 'Can View Logs',
    },
    'EXPORT_LOG_REPORT': {
        key: 'EXPORT_LOG_REPORT',
        formattedPermission: 'Can Export Log Report',
    },
    'LIST_SERVICE_CHARGES': {
        key: 'LIST_SERVICE_CHARGES',
        formattedPermission: 'Can View Service Charge List',
    },
    'ADD_SERVICE_CHARGE': {
        key: 'ADD_SERVICE_CHARGE',
        formattedPermission: 'Can Add Service Charge',
    },
    'EDIT_SERVICE_CHARGE': {
        key: 'EDIT_SERVICE_CHARGE',
        formattedPermission: 'Can Edit Service Charge',
    },
    'DELETE_SERVICE_CHARGE': {
        key: 'DELETE_SERVICE_CHARGE',
        formattedPermission: 'Can Delete Service Charge',
    },
    'LIST_TAX_RATES': {
        key: 'LIST_TAX_RATES',
        formattedPermission: 'Can View Tax Rate List',
    },
    'ADD_TAX_RATE': {
        key: 'ADD_TAX_RATE',
        formattedPermission: 'Can Add Tax Rate',
    },
    'EDIT_TAX_RATE': {
        key: 'EDIT_TAX_RATE',
        formattedPermission: 'Can Edit Tax Rate',
    },
    'DELETE_TAX_RATE': {
        key: 'DELETE_TAX_RATE',
        formattedPermission: 'Can Delete Tax Rate',
    },
    'LIST_GST': {
        key: 'LIST_GST',
        formattedPermission: 'Can View GST List',
    },
    'ADD_GST': {
        key: 'ADD_GST',
        formattedPermission: 'Can Add GST',
    },
    'EDIT_GST': {
        key: 'EDIT_GST',
        formattedPermission: 'Can Edit GST',
    },
    'DELETE_GST': {
        key: 'DELETE_GST',
        formattedPermission: 'Can Delete GST',
    },
    'LIST_SUPPORT_QUERY': {
        key: 'LIST_SUPPORT_QUERY',
        formattedPermission: 'Can View Support Query List',
    },
    'VIEW_SUPPORT_QUERY': {
        key: 'VIEW_SUPPORT_QUERY',
        formattedPermission: 'Can View Support Query',
    },
    'LIST_USER_ROLE': {
        key: 'LIST_USER_ROLE',
        formattedPermission: 'Can View User Role List',
    },
    'ADD_USER_ROLE': {
        key: 'ADD_USER_ROLE',
        formattedPermission: 'Can Add User Role',
    },
    'EDIT_USER_ROLE': {
        key: 'EDIT_USER_ROLE',
        formattedPermission: 'Can Edit User Role',
    },
    'LIST_PERMISSION_GROUP': {
        key: 'LIST_PERMISSION_GROUP',
        formattedPermission: 'Can View Permission Group List',
    },
    'ADD_PERMISSION_GROUP': {
        key: 'ADD_PERMISSION_GROUP',
        formattedPermission: 'Can Add Permission Group',
    },
    'EDIT_PERMISSION_GROUP': {
        key: 'EDIT_PERMISSION_GROUP',
        formattedPermission: 'Can Edit Permission Group',
    },
    'DELETE_PERMISSION_GROUP': {
        key: 'DELETE_PERMISSION_GROUP',
        formattedPermission: 'Can Delete Permission Group',
    },
    'LIST_ADMIN_USERS': {
        key: 'LIST_ADMIN_USERS',
        formattedPermission: 'Can View Admin User List',
    },
    'ADD_ADMIN_USER': {
        key: 'ADD_ADMIN_USER',
        formattedPermission: 'Can Add Admin User',
    },
    'EDIT_ADMIN_USER': {
        key: 'EDIT_ADMIN_USER',
        formattedPermission: 'Can Edit Admin User',
    },
    'DELETE_ADMIN_USER': {
        key: 'DELETE_ADMIN_USER',
        formattedPermission: 'Can Delete Admin User',
    },
    'FRANCHISE_STATION_ACCESS': {
        key: 'FRANCHISE_STATION_ACCESS',
        formattedPermission: 'Can Manage Franchise Station Access',
    },
    'LIST_STATIONS': {
        key: 'LIST_STATIONS',
        formattedPermission: 'Can View Station List',
    },
    'VIEW_STATION': {
        key: 'VIEW_STATION',
        formattedPermission: 'Can View Station'
    },
    'ADD_STATION': {
        key: 'ADD_STATION',
        formattedPermission: 'Can Add Station',
    },
    'EDIT_STATION': {
        key: 'EDIT_STATION',
        formattedPermission: 'Can Edit Station',
    },
    'DELETE_STATION': {
        key: 'DELETE_STATION',
        formattedPermission: 'Can Delete Station',
    },
    'MANAGE_STATION_CHARGERS': {
        key: 'MANAGE_STATION_CHARGERS',
        formattedPermission: 'Can Manage Station Chargers',
    },
    'VIEW_STATION_TARIFF': {
      key: 'VIEW_STATION_TARIFF',
      formattedPermission: 'Can View Station Tariff',
    },
    'VIEW_STATION_REVIEWS': {
        key: 'VIEW_STATION_REVIEWS',
        formattedPermission: 'Can View Station Reviews',
    },
    'LIST_API_CONSUMERS': {
        key: 'LIST_API_CONSUMERS',
        formattedPermission: 'Can View API Consumer List',
    },
    'ADD_API_CONSUMER': {
        key: 'ADD_API_CONSUMER',
        formattedPermission: 'Can Add API Consumer',
    },
    'EDIT_API_CONSUMER': {
        key: 'EDIT_API_CONSUMER',
        formattedPermission: 'Can Edit API Consumer',
    },
    'DELETE_API_CONSUMER': {
        key: 'DELETE_API_CONSUMER',
        formattedPermission: 'Can Delete API Consumer',
    },
    'VIEW_API_CONSUMER': {
        key: 'VIEW_API_CONSUMER',
        formattedPermission: 'Can View API Consumer',
    },
    'LIST_TARIFFS': {
        key: 'LIST_TARIFFS',
        formattedPermission: 'Can View Tariff List',
    },
    'ADD_TARIFF': {
        key: 'ADD_TARIFF',
        formattedPermission: 'Can Add Tariff',
    },
    'EDIT_TARIFF': {
        key: 'EDIT_TARIFF',
        formattedPermission: 'Can Edit Tariff',
    },
    'DELETE_TARIFF': {
        key: 'DELETE_TARIFF',
        formattedPermission: 'Can Delete Tariff',
    },
    'LIST_TARIFF_ASSIGNMENTS': {
        key: 'LIST_TARIFF_ASSIGNMENTS',
        formattedPermission: 'Can View Tariff Assignment List',
    },
    'ADD_TARIFF_ASSIGNMENT': {
        key: 'ADD_TARIFF_ASSIGNMENT',
        formattedPermission: 'Can Add Tariff Assignment',
    },
    'EDIT_TARIFF_ASSIGNMENT': {
        key: 'EDIT_TARIFF_ASSIGNMENT',
        formattedPermission: 'Can Edit Tariff Assignment',
    },
    'DELETE_TARIFF_ASSIGNMENT': {
        key: 'DELETE_TARIFF_ASSIGNMENT',
        formattedPermission: 'Can Delete Tariff Assignment',
    },
    'LIST_COMPANIES': {
        key: 'LIST_COMPANIES',
        formattedPermission: 'Can View Company List',
    },
    'ADD_COMPANY': {
        key: 'ADD_COMPANY',
        formattedPermission: 'Can Add Company',
    },
    'EDIT_COMPANY': {
        key: 'EDIT_COMPANY',
        formattedPermission: 'Can Edit Company',
    },
    'DELETE_COMPANY': {
        key: 'DELETE_COMPANY',
        formattedPermission: 'Can Delete Company',
    },
    'VIEW_COMPANY': {
        key: 'VIEW_COMPANY',
        formattedPermission: 'Can View Company',
    },
    'LIST_COMPANY_USERS': {
        key: 'LIST_COMPANY_USERS',
        formattedPermission: 'Can View Company User List',
    },
    'ADD_COMPANY_USER': {
        key: 'ADD_COMPANY_USER',
        formattedPermission: 'Can Add Company User',
    },
    'VIEW_COMPANY_USER': {
        key: 'VIEW_COMPANY_USER',
        formattedPermission: 'Can View Company User',
    },
    'EDIT_COMPANY_USER': {
        key: 'EDIT_COMPANY_USER',
        formattedPermission: 'Can Edit Company User',
    }
}

export type PermissionKeys = keyof typeof permissionConfig;
export type Permission = typeof permissionConfig[PermissionKeys] & {
    order: number
};